#ifndef IOCTL_H
#define IOCTL_H

/* This file is empty since it only needs to exist on Windows
   but isn't otherwise used */

#endif /* IOCTL_H */