#ifndef FIO_STRLCAT_H
#define FIO_STRLCAT_H

size_t strlcat(char *dst, const char *src, size_t size);

#endif
