#ifndef FIO_STRNTOL_H
#define FIO_STRNTOL_H

long strntol(const char *str, size_t sz, char **end, int base);

#endif
